import { Box, Button, Stack, Typography } from "@mui/material";
import React from "react";
import { useNavigate } from "react-router-dom";

export default function ProductCard({product}) {
    const navigate = useNavigate()
    
  return (
    <>
      <Stack
        width={"100%"}
        height={"350px"}
        sx={{ boxShadow: "0 0 10px 1px rgba(0,0,0,0.5)", borderRadius: "8px" }}
      >
        <Box src={product?.image} component={"img"} height={"60%"} sx={{objectFit:"cover"}}/>
        <Stack p={2} gap={2}>
            <Typography variant="h5">
                {(product?.title).slice(0,15)+"..."}
            </Typography>
        </Stack>
        <Stack p={2}>
            <Button onClick={()=>navigate(`/product-details/${product?.id}`)} variant="contained">Show more</Button>
        </Stack>
      </Stack>
    </>
  );
}
