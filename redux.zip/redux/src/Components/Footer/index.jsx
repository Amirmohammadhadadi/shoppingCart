import React from 'react';
import {
  Box,
  Container,
  Grid,
  Typography,
  Link,
  IconButton,
  Divider,
} from '@mui/material';
import { Facebook, Twitter, Instagram, GitHub } from '@mui/icons-material';

export default function Footer() {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: '#0d47a1',
        color: '#fff',
        mt: 8,
        pt: 6,
        pb: 4,
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          {/* Logo + Description */}
          <Grid item xs={12} md={4}>
            <Typography variant="h5" fontWeight="bold" gutterBottom>
              MyWebsite
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.8 }}>
              We create meaningful digital experiences for everyone. Join us and grow together.
            </Typography>
          </Grid>

          {/* Quick Links */}
          <Grid item xs={6} md={2}>
            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Quick Links
            </Typography>
            <Link href="#" underline="hover" color="inherit" sx={{ display: 'block', mb: 1, opacity: 0.9, '&:hover': { opacity: 1 } }}>
              Home
            </Link>
            <Link href="#" underline="hover" color="inherit" sx={{ display: 'block', mb: 1, opacity: 0.9, '&:hover': { opacity: 1 } }}>
              About
            </Link>
            <Link href="#" underline="hover" color="inherit" sx={{ display: 'block', mb: 1, opacity: 0.9, '&:hover': { opacity: 1 } }}>
              Services
            </Link>
            <Link href="#" underline="hover" color="inherit" sx={{ display: 'block', opacity: 0.9, '&:hover': { opacity: 1 } }}>
              Contact
            </Link>
          </Grid>

          {/* Contact Info */}
          <Grid item xs={6} md={3}>
            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Contact Us
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.8 }}>
              Email: info@mywebsite.com
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.8 }}>
              Phone: +123 456 7890
            </Typography>
            <Typography variant="body2" sx={{ opacity: 0.8 }}>
              Address: 123 Main St, City, Country
            </Typography>
          </Grid>

          {/* Social Icons */}
          <Grid item xs={12} md={3}>
            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Follow Us
            </Typography>
            <Box>
              <IconButton href="#" sx={{ color: '#fff', '&:hover': { color: '#90caf9' } }}>
                <Facebook />
              </IconButton>
              <IconButton href="#" sx={{ color: '#fff', '&:hover': { color: '#90caf9' } }}>
                <Twitter />
              </IconButton>
              <IconButton href="#" sx={{ color: '#fff', '&:hover': { color: '#90caf9' } }}>
                <Instagram />
              </IconButton>
              <IconButton href="#" sx={{ color: '#fff', '&:hover': { color: '#90caf9' } }}>
                <GitHub />
              </IconButton>
            </Box>
          </Grid>
        </Grid>

        <Divider sx={{ my: 4, backgroundColor: 'rgba(255,255,255,0.2)' }} />

        <Typography variant="body2" align="center" sx={{ opacity: 0.6 }}>
          © {new Date().getFullYear()} MyWebsite. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
}
