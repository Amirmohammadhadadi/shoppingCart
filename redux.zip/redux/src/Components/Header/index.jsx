import React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Stack,
  Badge,
} from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

export default function Header() {
  const navigate = useNavigate()

  const cartCount = useSelector((state)=>state.cart.listItem.length)
  return (
    <AppBar position="static" color="primary" elevation={4}>
      <Toolbar sx={{ justifyContent: "space-between" }}>
        {/* Logo/Title */}
        <Typography variant="h6" component="div" sx={{ fontWeight: "bold" }}>
          MyWebsite
        </Typography>

        {/* Navigation buttons */}
        <Box sx={{ display: "flex", gap: 2 }}>
          <Link to={"/"}>
            <Button color="inherit">Home</Button>
          </Link>
          <Link to={"/product"}>
            {" "}
            <Button color="inherit">Product</Button>
          </Link>
          <Link>
            <Button color="inherit">Services</Button>
          </Link>
          <Link to={"/contact"}>
            {" "}
            <Button color="inherit">Contact</Button>{" "}
          </Link>
        </Box>

        {/* Right-side button (login/signup) */}
        <Stack flexDirection={"row"} gap={1}>
          <IconButton onClick={()=>navigate("/cart")}>
            <Badge showZero badgeContent={cartCount} color="secondary" >
              <ShoppingCartIcon sx={{ color: "white" }} />
            </Badge>
          </IconButton>
          <Button color="secondary" variant="contained">
            Login
          </Button>
        </Stack>
      </Toolbar>
    </AppBar>
  );
}
