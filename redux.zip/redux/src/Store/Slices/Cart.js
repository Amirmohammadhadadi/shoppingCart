import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  listItem: [],
  totalPrice: 0,
};

const cartSlice = createSlice({
  name: "cartSlice",
  initialState,
  reducers: {
    addItem: (state, action) => {
      const existingProduct = state.listItem.find(
        (e) => e.id === action.payload.id
      );

      if (existingProduct) {
        existingProduct.quantity += 1;
      } else {
        state.listItem.push({ ...action.payload, quantity: 1 });
      }

      
      state.totalPrice = state.listItem.reduce(
        (acc, item) => acc + item.price * item.quantity,
        0
      );
    },

    removeItem: (state, action) => {
      const existingProduct = state.listItem.find(
        (e) => e.id === action.payload.id
      );

      if (existingProduct) {
        if (existingProduct.quantity > 1) {
          existingProduct.quantity -= 1;
        } else {
          state.listItem = state.listItem.filter(
            (e) => e.id !== action.payload.id
          );
        }

   
        state.totalPrice = state.listItem.reduce(
          (acc, item) => acc + item.price * item.quantity,
          0
        );
      }
    },

    clearItem: (state) => {
      state.listItem = [];
      state.totalPrice = 0;
    },
  },
});

export const { addItem, removeItem, clearItem } = cartSlice.actions;
export default cartSlice.reducer;
