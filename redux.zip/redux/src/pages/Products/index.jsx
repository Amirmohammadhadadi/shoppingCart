import React, { useEffect, useState } from "react";
import ProductCard from "../../Components/ProductCard";
import { Grid } from "@mui/material";

export default function Products() {
  const [data, setData] = useState([]);
  useEffect(() => {
    (async () => {
      const res = await fetch(
        'https://fakestoreapi.com/products'
      );
      const data = await res.json();
      setData(data);
    })();
  }, []);

  const items = data?.map((e, index) => {
    return (
      <Grid size={4} key={index}>
        <ProductCard product={e} />
      </Grid>
    );
  });

  return (
    <>
      <Grid container spacing={2} margin={"16px 32px"}>
        {items}
      </Grid>
    </>
  );
}
