import React from "react";
import {
  Box,
  Card,
  CardMedia,
  CardContent,
  Typography,
  Button,
  Grid,
  Rating,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { addItem, removeItem, clearItem } from "../../Store/Slices/Cart";

const product = {
  id: 5,
  title:
    "John Hardy Women's Legends Naga Gold & Silver Dragon Station Chain Bracelet",
  price: 695,
  description:
    "From our Legends Collection, the Naga was inspired by the mythical water dragon that protects the ocean's pearl. Wear facing inward to be bestowed with love and abundance, or outward for protection.",
  category: "jewelery",
  image: "https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg",
  rating: {
    rate: 4.6,
    count: 400,
  },
};

export default function Cart() {
  const dispatch = useDispatch();
  const { listItem, totalPrice } = useSelector((state) => state.cart);
  const items = listItem?.map((e, index) => {
    return (
      <Card key={index} sx={{ display: "flex", gap: 2, p: 2, mb: 3 }}>
        <CardMedia
          component="img"
          image={e.image}
          alt={e.title}
          sx={{ width: 150, objectFit: "contain" }}
        />

        <CardContent sx={{ flex: 1 }}>
          <Typography variant="h6">{e.title}</Typography>
          <Typography variant="body2" color="text.secondary" my={1}>
            {e.description}
          </Typography>
          <Typography variant="h6" color="primary">
            ${e.price}
          </Typography>

          <Box display="flex" alignItems="center" mt={1}>
            <Rating value={e.rating.rate} precision={0.1} readOnly />
            <Typography variant="body2" ml={1}>
              ({e.rating.count})
            </Typography>
          </Box>

          <Box mt={2} display="flex" alignItems="center" gap={1}>
            <Button variant="outlined" onClick={()=>dispatch(removeItem(e))}>-</Button>
            <Typography>{e.quantity}</Typography>
            <Button variant="outlined" onClick={()=>dispatch(addItem(e))}>+</Button>
          </Box>
        </CardContent>
      </Card>
    );
  });

  return (
    <Box p={4}>
      <Typography variant="h4" gutterBottom>
        🛒 سبد خرید
      </Typography>

      {items}
      <Box textAlign="right">
        <Typography variant="h6">مجموع: ${totalPrice}</Typography>
        <Button variant="contained" color="success" sx={{ mt: 2 }}>
          ادامه پرداخت
        </Button>
        <Button
          variant="contained"
          color="error"
          sx={{ mt: 2 }}
          onClick={() => dispatch(clearItem())}
        >
          خالی کردن سبد خرید
        </Button>
      </Box>
    </Box>
  );
}
