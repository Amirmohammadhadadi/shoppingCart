import React from 'react';
import {
  Box,
  Typography,
  Container,
  Grid,
  Button,
  Card,
  CardMedia,
  CardContent,
  CardActions,
} from '@mui/material';

const sampleProducts = [
  {
    id: 1,
    title: 'Wireless Headphones',
    price: '$99.99',
    image: 'https://via.placeholder.com/300x200?text=Headphones',
  },
  {
    id: 2,
    title: 'Smart Watch',
    price: '$149.99',
    image: 'https://via.placeholder.com/300x200?text=Watch',
  },
  {
    id: 3,
    title: 'Gaming Mouse',
    price: '$49.99',
    image: 'https://via.placeholder.com/300x200?text=Mouse',
  },
];

export default function Home() {
  return (
    <Box>
      {/* Hero Section */}
      <Box
        sx={{
          backgroundImage: 'url(https://via.placeholder.com/1200x400?text=Welcome+to+Our+Shop)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          py: 10,
          textAlign: 'center',
          color: '#fff',
        }}
      >
        <Typography variant="h2" fontWeight="bold">
          Welcome to MyShop
        </Typography>
        <Typography variant="h6" sx={{ mt: 2 }}>
          Discover the best deals on tech gadgets, wearables, and more!
        </Typography>
        <Button variant="contained" color="secondary" sx={{ mt: 4 }}>
          Shop Now
        </Button>
      </Box>

      {/* Featured Products */}
      <Container sx={{ py: 8 }}>
        <Typography variant="h4" gutterBottom fontWeight="bold" textAlign="center">
          Featured Products
        </Typography>

        <Grid container spacing={4} sx={{ mt: 2 }}>
          {sampleProducts.map((product) => (
            <Grid item xs={12} sm={6} md={4} key={product.id}>
              <Card sx={{ height: '100%' }}>
                <CardMedia
                  component="img"
                  height="200"
                  image={product.image}
                  alt={product.title}
                />
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    {product.title}
                  </Typography>
                  <Typography variant="body1" color="text.secondary">
                    {product.price}
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button fullWidth variant="contained" color="primary">
                    Add to Cart
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Call to Action */}
      <Box
        sx={{
          backgroundColor: '#0d47a1',
          color: '#fff',
          textAlign: 'center',
          py: 6,
          mt: 8,
        }}
      >
        <Typography variant="h5" fontWeight="bold">
          Subscribe & Get 10% Off Your First Order!
        </Typography>
        <Typography variant="body1" sx={{ mt: 1 }}>
          Join our newsletter for exclusive offers and updates.
        </Typography>
        <Button variant="outlined" sx={{ mt: 3, color: '#fff', borderColor: '#fff' }}>
          Subscribe
        </Button>
      </Box>
    </Box>
  );
}
