import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Container,
  Typography,
  Grid,
  Card,
  CardMedia,
  CardContent,
  CircularProgress,
  Button,
  Box,
  IconButton,
  TextField,
} from "@mui/material";
import { Chip } from '@mui/material';

import { useDispatch, useSelector } from "react-redux";
import { addItem, removeItem } from "../../Store/Slices/Cart";

export default function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const { listItem } = useSelector((state) => state.cart);
  const existingProduct = listItem.find((e) => e.id == id);

  const dispatch = useDispatch();

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`https://fakestoreapi.com/products/${id}`);
        const data = await res.json();
        setProduct(data);
      } catch (error) {
        console.error("Fetch product error:", error);
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  if (loading)
    return (
      <Box textAlign="center" mt={5}>
        <CircularProgress />
      </Box>
    );

  if (!product)
    return <Typography textAlign="center">محصول پیدا نشد</Typography>;

  return (
    <Container maxWidth="md" sx={{ mt: 6, mb: 8 }}>
      <Grid container>
        <Grid size={6}>
          <Card
            sx={{
              borderRadius: 4,
              overflow: "hidden",
              boxShadow: 5,
              transition: "transform 0.3s",
              "&:hover": { transform: "scale(1.02)" },
            }}
          >
            <CardMedia
              component="img"
              image={product.image}
              alt={product.title}
              sx={{
                width: "100%",
                height: 450,
                objectFit: "contain",
                backgroundColor: "#fafafa",
              }}
            />
          </Card>
        </Grid>

        {/* جزئیات */}
        <Grid size={6}>
          <CardContent>
            <Typography variant="h5" fontWeight="bold" gutterBottom>
              {product.title}
            </Typography>

            <Chip
              label={product.category}
              color="primary"
              variant="outlined"
              sx={{ mb: 2 }}
            />

            <Typography variant="h6" color="secondary" gutterBottom>
              قیمت: ${product.price.toFixed(2)}
            </Typography>

            <Typography
              variant="body1"
              color="text.secondary"
              sx={{ mt: 2, mb: 4 }}
            >
              {product.description}
            </Typography>

            {existingProduct ? (
              <>
                <Button variant="contained" color="success" onClick={() => dispatch(addItem(product))}>+</Button>
                <TextField value={existingProduct?.quantity} />
                <Button variant="contained" color="error" onClick={() => dispatch(removeItem(product))}>-</Button>

              </>
            ) : (
              <Button
                onClick={() => dispatch(addItem(product))}
                variant="contained"
                fullWidth
                size="large"
                sx={{
                  borderRadius: 3,
                  py: 1.5,
                  fontWeight: "bold",
                  backgroundColor: "#111",
                  "&:hover": { backgroundColor: "#333" },
                }}
              >
                افزودن به سبد خرید
              </Button>
            )}
          </CardContent>
        </Grid>
      </Grid>
    </Container>
  );
}
